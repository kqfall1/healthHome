import sqlite3

# Function to initialize the database
def init_db():
    # Connect to the SQLite database (creates the database file if it doesn't exist)
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Create the 'users' table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK (role IN ('gym-goer', 'trainer', 'admin'))
        )
    ''')

    # Create the 'bmi_logs' table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS bmi_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            bmi REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')

    # Commit changes and close the connection
    conn.commit()
    conn.close()
    print("Database initialized successfully!")

# Reusable function to connect to the database
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row  # Enables dictionary-like access to rows
    return conn

# Reusable function to retrieve BMI logs for a specific user
def get_bmi_logs_for_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM bmi_logs WHERE user_id = ? ORDER BY created_at ASC', (user_id,))
    logs = cursor.fetchall()
    conn.close()
    return logs

# Reusable function to add a new BMI log
def add_bmi_log(user_id, bmi):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO bmi_logs (user_id, bmi) VALUES (?, ?)', (user_id, bmi))
    conn.commit()
    conn.close()
    print(f"New BMI log added for user_id {user_id}.")

# Main entry point to initialize the database when the script is run
if __name__ == "__main__":
    init_db()