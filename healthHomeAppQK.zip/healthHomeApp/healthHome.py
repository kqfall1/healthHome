from flask import Flask, jsonify, render_template, request, redirect, url_for, flash, session
import sqlite3
import bcrypt

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/register/', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')  # Only get email
        password = request.form.get('password')
        role = request.form.get('role')

        # Check for existing email
        conn = get_db_connection()
        existing_user = conn.execute(
            'SELECT * FROM users WHERE email = ?', (email,)
        ).fetchone()
        conn.close()

        if existing_user:
            flash('Email already exists. Please try again.', 'error')
            return render_template('register.html')

        # Hash the password and save the user
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        conn = get_db_connection()
        print(f"Role: {role}, Email: {email}, Password Hash: {password_hash}")
        conn.execute(
            'INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)',
            (email, password_hash, role)
        )
        conn.commit()
        conn.close()

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        conn.close()

        if user and bcrypt.checkpw(password.encode('utf-8'), user['password_hash']):
            session['user_id'] = user['id']  # Save user ID to session
            print("Session User ID after login:", session.get('user_id'))
            session['role'] = user['role']  # Save user role to session
            flash('Login successful! Welcome back.', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid email or password.', 'error')

    return render_template('login.html')

@app.route('/')
def home():
    role = session.get('role')  # Get the role from the session (if logged in)
    return render_template('index.html', role=role)

@app.route('/about/')
def about():
    return render_template('about.html')

# Route for BMI calculation
@app.route('/bmi/', methods=['GET', 'POST'])
def bmi():
    if request.method == 'POST':
        try:
            # Get form data
            weight = float(request.form.get('weight'))
            height_feet = float(request.form.get('height-feet'))
            height_inches = float(request.form.get('height-inches'))

            # Calculate BMI
            total_height_inches = (height_feet * 12) + height_inches
            height_meters = total_height_inches * 0.0254
            weight_kg = weight * 0.453592
            bmi = round(weight_kg / (height_meters ** 2), 2)

            # Debug: Output calculated BMI
            print(f"Calculated BMI: {bmi}")

            # Save BMI to the database
            user_id = session.get('user_id')  # Retrieve user ID from session
            if user_id:
                conn = get_db_connection()
                cursor = conn.cursor()

                # Check if a BMI log already exists for the user
                cursor.execute('SELECT id FROM bmi_logs WHERE user_id = ?', (user_id,))
                existing_log = cursor.fetchone()

                if existing_log:
                    # Update the existing log
                    print(f"Updating existing BMI log for user_id: {user_id}")
                    cursor.execute(
                        'UPDATE bmi_logs SET bmi = ?, created_at = CURRENT_TIMESTAMP WHERE user_id = ?',
                        (bmi, user_id)
                    )
                else:
                    # Insert a new BMI log
                    print(f"Inserting new BMI log for user_id: {user_id} with BMI: {bmi}")
                    cursor.execute(
                        'INSERT INTO bmi_logs (user_id, bmi) VALUES (?, ?)',
                        (user_id, bmi)
                    )

                conn.commit()
                conn.close()
                print("BMI log successfully saved!")
            else:
                print("User is not logged in. Cannot save BMI.")

            # Return the calculated BMI as a JSON response
            return jsonify({'bmi': bmi})

        except Exception as e:
            print(f"An error occurred while processing BMI: {e}")
            return jsonify({'error': 'An error occurred while calculating BMI.'}), 500

    # Render the BMI page on GET request
    return render_template('bmi.html')

@app.route('/bmi-history/')
def bmi_history():
    return render_template('bmiHistory.html')

@app.route('/bmi-history-data/')
def bmi_history_data():
    print("Session User ID in BMI history route:", session.get('user_id'))
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'User not logged in'}), 401

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Retrieve all BMI entries for the user
    cursor.execute('SELECT bmi, created_at FROM bmi_logs WHERE user_id = ? ORDER BY created_at ASC', (user_id,))
    history = cursor.fetchall()
    conn.close()

    # Format the data as JSON
    bmi_data = [{'bmi': row[0], 'date': row[1]} for row in history]
    return jsonify(bmi_data)

@app.route('/logs/')
def logs():
    if 'user_id' not in session or session['role'] != 'gym-goer':
        flash('Unauthorized access.', 'error')
        return redirect(url_for('login'))
    return render_template('logs.html')

@app.route('/logout/')
def logout():
    session.clear()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('home'))

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row  # Access rows as dictionaries
    return conn

if __name__ == '__main__':
    app.run(debug=True)